Questions about the pigpio library are welcome but we ask that you check these resources first:
* [pigpio library web page](http://abyz.me.uk/rpi/pigpio)  
Noobs should start with the FAQ.  All
APIs are documented extensively.
* Search the repository issues with a 'question' label
For example, to search for information on PWM type in search box:
`label:question pwm`
* Check the repository's Wiki - WIP, help wanted.
